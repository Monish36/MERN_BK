## Hi! Thanks for looking here! Project is in build now 🏗️ But soon I will be proud to show the results
21.03
# Project is in final version now! You can see it on https://www.youtube.com/watch?v=PE2qmve0fqE
 Done:  
    ✅ Reservation system (on backend)  
    ✅ Auth system  
    ✅ Storaging session in DB (you stay logged on the same device, even you exit site or server restart)  
    ✅ Option to create admin user with secret key  
    ✅ Base front for login and registering  
    ✅ Reservation system (front)  
    ✅ Using react-calendar package for reservation calendar  
    ✅ Admin dashboard, you can see last orders and delete  
    How it looks (18.03)
    ![226098871-21104562-a5c1-41a8-b7e7-b12854ff56a0](https://user-images.githubusercontent.com/34983870/226171238-4e4e0dbf-eeec-4608-b4c0-b8c9525a475f.png)
    How it looks (19.03)
    ![Screenshot 2023-03-19 115121](https://user-images.githubusercontent.com/34983870/226171247-353bc0c9-83b6-42a9-a9c6-a0fd33b785ce.png)
    How it looks (21.03)
    Functional reservation calendar, created cool modal for order confirmation, admin dashboard
    ![Screenshot 2023-03-20 171322](https://user-images.githubusercontent.com/34983870/226402103-2b1b7785-e526-4821-afca-d89d8c66c65a.png)
    ![Screenshot 2023-03-21 124721](https://user-images.githubusercontent.com/34983870/226600674-a3ddfa56-4773-4288-b5a9-3113b6311b74.png)

    
